Hey! I am Faizal Khan, developeer of this game. If you like it then please share like, comment and share with friends.
PS: *The game has a bug of spawning rotten fruit at a very low height thus giving damage to player. It will be fixed in later versions.*
PLATFORMS AVAILABLE:
1. Aandroid
2. PC
3. WebGL
4. IOS
5. iphone(will be added in the next version)
THANKS.